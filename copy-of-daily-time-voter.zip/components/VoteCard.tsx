import React, { ReactNode } from 'react';
import { VoteOption } from '../types';
import { Check, Trophy, Cpu } from 'lucide-react';

type Theme = 'cyan' | 'orange';

interface VoteCardProps {
  option: VoteOption;
  theme: Theme;
  icon: ReactNode;
  subLabel: string;
  selected?: boolean;
  disabled?: boolean;
  onClick: () => void;
  percentage?: number;
  votes?: number;
  isResultMode?: boolean;
}

export const VoteCard: React.FC<VoteCardProps> = ({
  option,
  theme,
  icon,
  subLabel,
  selected,
  disabled,
  onClick,
  percentage = 0,
  votes = 0,
  isResultMode = false,
}) => {
  const isWinning = percentage >= 50;

  // Dev Theme Configurations
  const styles = {
    cyan: {
      // Unselected: Dark Glass
      base: 'bg-slate-800/50 backdrop-blur-md border-slate-700 hover:border-cyan-500/50 hover:bg-slate-800/80',
      // Selected: Neon Cyan Glow
      selected: 'bg-gradient-to-br from-cyan-900/90 to-blue-900/90 border-cyan-400/50 text-white shadow-[0_0_30px_rgba(6,182,212,0.3)]',
      // Text (Unselected)
      text: 'text-slate-300',
      subText: 'text-cyan-400',
      // Logo/Icon Circle
      logoBg: 'bg-slate-900/50 text-cyan-400 border border-cyan-500/20',
      logoRing: 'ring-cyan-500/10',
      // Progress Bar
      progressMain: 'bg-gradient-to-r from-cyan-500 to-blue-500',
    },
    orange: {
      // Unselected
      base: 'bg-slate-800/50 backdrop-blur-md border-slate-700 hover:border-orange-500/50 hover:bg-slate-800/80',
      // Selected: Neon Orange Glow
      selected: 'bg-gradient-to-br from-orange-900/90 to-red-900/90 border-orange-400/50 text-white shadow-[0_0_30px_rgba(249,115,22,0.3)]',
      // Text (Unselected)
      text: 'text-slate-300',
      subText: 'text-orange-400',
      // Logo/Icon Circle
      logoBg: 'bg-slate-900/50 text-orange-400 border border-orange-500/20',
      logoRing: 'ring-orange-500/10',
      // Progress Bar
      progressMain: 'bg-gradient-to-r from-orange-500 to-red-500',
    }
  };

  const currentStyle = styles[theme];

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`
        relative group w-full md:w-80 p-8 rounded-2xl transition-all duration-300 ease-out
        border-[1px] flex flex-col items-center justify-center gap-6 overflow-hidden
        ${selected 
            ? `${currentStyle.selected} scale-105 ring-1 ring-white/10` 
            : `${currentStyle.base} hover:-translate-y-1`
        }
        ${disabled && !selected ? 'opacity-40 grayscale-[0.5] cursor-default scale-95' : 'cursor-pointer'}
      `}
    >
      {/* Background Tech Pattern for Selected */}
      {selected && (
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-from)_1px,_transparent_1px)] bg-[length:10px_10px]"></div>
      )}

      {/* Selection Badge */}
      {selected && (
        <div className="absolute top-3 right-3 bg-green-500 text-black rounded-md p-1.5 shadow-lg z-10 animate-in zoom-in duration-300">
          <Check className="w-5 h-5 stroke-[3]" />
        </div>
      )}
      
      {/* LOGO AREA */}
      <div className={`
        relative w-28 h-28 flex items-center justify-center rounded-2xl shadow-inner transition-transform duration-500 group-hover:rotate-3
        ${selected ? 'bg-white/10 text-white backdrop-blur-md ring-1 ring-white/20' : `${currentStyle.logoBg} ${currentStyle.logoRing}`}
      `}>
        {/* Icon */}
        {React.cloneElement(icon as React.ReactElement, { 
          className: `w-14 h-14 stroke-[1.5] drop-shadow-sm ${selected ? 'text-white' : ''}` 
        })}
      </div>

      {/* Text Content */}
      <div className="text-center space-y-2 relative z-10">
        <span className={`font-mono text-6xl font-bold tracking-tighter drop-shadow-sm ${selected ? 'text-white' : currentStyle.text}`}>
          {option}
        </span>
        <p className={`font-mono text-sm font-bold tracking-wider ${selected ? 'text-white/80' : currentStyle.subText}`}>
          {`// ${subLabel}`}
        </p>
      </div>

      {/* Results View */}
      {isResultMode && (
        <div className="w-full mt-6 space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-700 relative z-10 font-mono">
          <div className={`flex justify-between text-sm font-bold ${selected ? 'text-white' : 'text-slate-400'}`}>
            <span className="flex items-center gap-2">
               {isWinning && <Trophy className="w-4 h-4 text-yellow-400" />}
               count: {votes}
            </span>
            <span>{`{ ${percentage.toFixed(0)}% }`}</span>
          </div>
          
          {/* Progress Bar */}
          <div className={`w-full rounded-full h-3 overflow-hidden p-[2px] ${selected ? 'bg-black/30' : 'bg-slate-700 border border-slate-600'}`}>
            <div
              className={`h-full rounded-full shadow-sm transition-all duration-1000 ease-out ${selected ? 'bg-white' : currentStyle.progressMain}`}
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>
      )}

      {/* Call to Action (Hover) */}
      {!isResultMode && !disabled && (
        <div className={`
          mt-4 px-6 py-2 rounded-lg text-sm font-mono font-bold transition-all duration-300 border
          ${selected 
            ? 'bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.4)]' 
            : 'bg-transparent border-slate-600 text-slate-400 group-hover:border-slate-400 group-hover:text-slate-200'
          }
        `}>
          &lt;Vote /&gt;
        </div>
      )}
    </button>
  );
};