export enum VoteOption {
  ELEVEN = '11:00',
  TWELVE = '12:00',
}

export interface VoteState {
  [VoteOption.ELEVEN]: number;
  [VoteOption.TWELVE]: number;
}

export interface UserVote {
  hasVoted: boolean;
  selectedOption: VoteOption | null;
}