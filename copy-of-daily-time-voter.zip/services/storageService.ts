import { VoteOption, VoteState, UserVote } from '../types';

const VOTES_KEY = 'daily_votes_data';
const USER_VOTE_KEY = 'daily_user_has_voted';

const INITIAL_VOTES: VoteState = {
  [VoteOption.ELEVEN]: 0,
  [VoteOption.TWELVE]: 0,
};

export const getVotes = (): VoteState => {
  try {
    const stored = localStorage.getItem(VOTES_KEY);
    return stored ? JSON.parse(stored) : INITIAL_VOTES;
  } catch (e) {
    console.error("Error reading votes from storage", e);
    return INITIAL_VOTES;
  }
};

export const saveVote = (option: VoteOption): VoteState => {
  const currentVotes = getVotes();
  const newVotes = {
    ...currentVotes,
    [option]: (currentVotes[option] || 0) + 1,
  };
  localStorage.setItem(VOTES_KEY, JSON.stringify(newVotes));
  return newVotes;
};

export const getUserVoteStatus = (): UserVote => {
  try {
    const stored = localStorage.getItem(USER_VOTE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    // ignore
  }
  return { hasVoted: false, selectedOption: null };
};

export const setUserVoteStatus = (option: VoteOption) => {
  const status: UserVote = { hasVoted: true, selectedOption: option };
  localStorage.setItem(USER_VOTE_KEY, JSON.stringify(status));
};

export const resetAllData = () => {
  localStorage.removeItem(VOTES_KEY);
  localStorage.removeItem(USER_VOTE_KEY);
};